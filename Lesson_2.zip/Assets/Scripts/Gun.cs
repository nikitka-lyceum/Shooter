using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Gun : MonoBehaviour
{
    [SerializeField] private Bullet _bullet;
    [SerializeField] private float _shotPeriod = 0.5f;
    [SerializeField] private Transform _spawn;
    [SerializeField] private float _bulletSpeed = 20;


    private float _timer;

    private void Update()
    {
        _timer += Time.deltaTime;


        if (Input.GetMouseButton(0))
        {
            if (_timer > _shotPeriod)
            {
                Bullet newBullet = Instantiate(_bullet, _spawn.position, _spawn.rotation);
                newBullet.GetComponent<Rigidbody>().velocity = _spawn.forward * _bulletSpeed;
                _timer = 0;
            }
        }
        
    }
}
