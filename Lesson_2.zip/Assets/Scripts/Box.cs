using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Box : MonoBehaviour
{

    [SerializeField] private GameObject _hideObject;
    [SerializeField] private GameObject[] _planks;
    [SerializeField] private BoxCollider _collider;

    [SerializeField] private Coin _coin;

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.GetComponent<Bullet>())
        {
            _hideObject.SetActive(false);
            _collider.enabled = false;

            for (int i = 0; i < _planks.Length; i++)
            {
                Rigidbody planceRigidBody = _planks[i].AddComponent<Rigidbody>();
                planceRigidBody.velocity = Vector3.up * 6f;
                _planks[i].AddComponent<BoxCollider>();
            }


            Instantiate(_coin, transform.position, Quaternion.identity);
        }
    }
}
