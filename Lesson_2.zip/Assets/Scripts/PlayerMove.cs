using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMove : MonoBehaviour
{
    [SerializeField] private float _speed = 5f;
    private Rigidbody _rigidbody;
    [SerializeField] private Transform _playerModel;
    [SerializeField] private float _mouseSensitivity = 1f;
    [SerializeField] private Transform _cameraTransform;
    [SerializeField] private float _jumpSpeed = 5f;


    [SerializeField] private GameObject winText;


    private float _xAngle;
    private bool _grounded;

    private int _coinCount = 0;

    private void Start()
    {
        _rigidbody = GetComponent<Rigidbody>();

        winText.SetActive(false);
    }

    void Update()
    {
        float horizontalInput = Input.GetAxis("Horizontal");
        float verticalInput = Input.GetAxis("Vertical");


        // Shift
        if (Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift))
        {
            horizontalInput *= 2;
            verticalInput *= 2;
        }

        Vector3 inputVector = new Vector3(horizontalInput, 0, verticalInput);
        Vector3 worldVelovity = _playerModel.TransformVector(inputVector) * _speed;

        _rigidbody.velocity = new Vector3(worldVelovity.x, _rigidbody.velocity.y, worldVelovity.z);

        float mouseX = Input.GetAxis("Mouse X");
        float mouseY = Input.GetAxis("Mouse Y");

        _playerModel.localEulerAngles += new Vector3(0, mouseX * _mouseSensitivity, 0);

        _xAngle -= mouseY * _mouseSensitivity;
        _xAngle = Mathf.Clamp(_xAngle, -80, 80);

        _cameraTransform.localEulerAngles = new Vector3(_xAngle, 0, 0);
    
        if (Input.GetKeyDown(KeyCode.Space) && _grounded)
        {
            _rigidbody.velocity += Vector3.up * _jumpSpeed;
        }

        
        // Cursor
        if (Input.GetKeyDown(KeyCode.Escape)) {
            Cursor.lockState = CursorLockMode.None;
        }
        else
        {
            Cursor.lockState = CursorLockMode.Locked;
        }

        // Check Coin
        CheckCoinCount();
    }


    private void CheckCoinCount()
    {
        if (_coinCount == 4)
        {
            winText.SetActive(true); 
            _coinCount = 0;
        }
    }

    private void OnCollisionEnter(Collision collision)
    {
        if (collision.gameObject.GetComponent<Coin>()) 
        { 
            _coinCount++;
            Destroy(collision.gameObject);
        }
    }

    private void OnCollisionStay(Collision collision)
    {
        if (Vector3.Angle(collision.contacts[0].normal, Vector3.up) < 40f)
        _grounded = true;
    }

    private void OnCollisionExit(Collision collision)
    {
        _grounded = false;
    }
}
